Relevant .as files to comp SWF files

Sector.swf
-AppFan.as
-Ball.as
-Triangle.as
-Vector2D.as
-Math2.as

Scene1.swf
-scene1.as
-Vector2D.as
-Math2.as

Examples.swf
-Region2.swf
-Vector2D.as
-Math2.as